const express = require('express');
const mysql = require('mysql');
const path = require('path');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');

dotenv.config({path: './.env'});
// Create connection
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Connect
db.connect((err) => {
    if(err){
        throw err;
    }

});

const app = express();

const publicDirectory = path.join( __dirname, './public' );
app.use( express.static( publicDirectory ));

app.use(express.urlencoded({extended: false}));
app.use(cookieParser());

// Define routes

app.use('/', require('./routes/pages'));
app.use('/auth', require('./routes/auth'));
app.use('/project', require('./routes/project'));

app.listen('3001');

