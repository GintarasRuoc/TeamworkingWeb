const { query } = require('express');
const express = require('express');
const path = require('path');

const router = express.Router();

router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/index.html'));
})

router.get('/logOut', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/index.html'));
})

router.get('/project', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/project.html'));
})

router.get('/example', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/example.html'));
})

module.exports = router;