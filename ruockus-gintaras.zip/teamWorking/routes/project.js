const express = require('express');
const projectController = require('../controllers/projectPanel');
const projectBoard = require('../controllers/projectTasks');

const router = express.Router();

router.get('/check', projectController.check);
router.post('/changeProjectName', projectController.changeProjectName);
router.get('/deleteProject', projectController.deleteProject);
router.post('/addMember', projectController.addMember);
router.post('/changeMemberRole', projectController.changeMemberRole);
router.post('/kickMember', projectController.kickMember);
router.get('/getMembers', projectController.getMembers);

router.get('/getBoards', projectBoard.getBoards);
router.post('/addBoard', projectBoard.addBoard);
router.post('/editBoard', projectBoard.editBoard);
router.post('/openBoard', projectBoard.openBoard);
router.get('/deleteBoard', projectBoard.deleteBoard);
router.post('/addTask', projectBoard.addTask);
router.post('/getTasksInfo', projectBoard.getTasksInfo);
router.post('/editTask', projectBoard.editTask);
router.get('/deleteTasks', projectBoard.deleteTasks)
module.exports = router;