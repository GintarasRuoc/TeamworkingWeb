const express = require('express');
const authController = require('../controllers/auth');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/user', authController.user);
router.post('/projectCreate', authController.projectCreate);
router.get('/getProjects', authController.getProjects);
router.get('/getName', authController.getName);
router.post('/changeAccountSettings', authController.changeAccountSettings);
router.get('/logOut', authController.logOut);
router.get('/checkLogin', authController.checkLogin);
router.post('/project', authController.project);

module.exports = router;