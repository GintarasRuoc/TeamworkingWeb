// Registration
const registerForm = document.getElementById("register-form");
const registerButton = document.getElementById("register-form-submit");
var registerErrorMsg = document.getElementById("register-error-msg");
registerButton.addEventListener("click", (e) => { 
    e.stopPropagation()

    const firstName = registerForm.inputFirstName.value;
    const lastName = registerForm.inputLastName.value;
    const email = registerForm.inputEmail.value;
    const psw = registerForm.inputPassword.value;
    const confirmPsw = registerForm.inputConfirmPassword.value;
    const checkBox = registerForm.checkBox.checked;
    $.ajax({ 
        url:        "/auth/register",
        type:       "POST",
        dataType:   "json",
        data:       {firstName: firstName, lastName: lastName, email: email, psw: psw, confirmPsw: confirmPsw, checkBox: checkBox},
        success: function(data){
            registerErrorMsg.style.opacity = 1;
            registerErrorMsg.innerText = "Account registered succesfuly";


        },
        error: function (jqXHR, textStatus, errorThrown ){
                registerErrorMsg.innerText = jqXHR.responseText;
                registerErrorMsg.style.opacity = 1;
        }
    })
});

// Login request
const loginForm = document.getElementById("login-form");
const loginButton = document.getElementById("login-form-submit");
var loginErrorMsg = document.getElementById("login-error-msg");

loginButton.addEventListener("click", (e) => {
    e.preventDefault();

    const email = loginForm.inputEmail.value;
    const psw = loginForm.inputPassword.value;
    $.ajax({ 
        url:        "/auth/login",
        type:       "POST",
        dataType:   "json",
        data:       {email: email, psw: psw},
        success: function(data){
            document.getElementById("navLoggedOut").style.display = 'none';
            var navLoggedIn = document.getElementById("navLoggedIn");
            navLoggedIn.style.display = 'flex';
            document.getElementById("accountUserName").innerText = data.user;
            getName();
            getProjects();
        },
        error: function (jqXHR, textStatus, errorThrown ){
                if(jqXHR.status = 400){
                    loginErrorMsg.innerText = jqXHR.responseText;
                    loginErrorMsg.style.opacity = 1;
                }
        }
    })
});

// Display user name
function getName(){
    $.ajax({
        url:        "/auth/getName",
        type:       "GET",
        dataType:   "json",
        success: function(data){
            if(data){
                document.getElementById('accountSettingsUserEmail').innerText = data[0];
                accountSettingsForm.inputFirstName.value = data[1];
                accountSettingsForm.inputLastName.value = data[2];
            }
        },
        error: function (jqXHR, textStatus, errorThrown ){
                console.log(jqXHR.responseText);
        }
    })
}

// Change account settings
const accountSettingsForm = document.getElementById("account-settings-form");
const accountSettingsButton = document.getElementById("account-settings-form-submit");
var accountSettingsErrorMsg = document.getElementById("account-settings-error-msg");
accountSettingsButton.addEventListener("click", (e) => {
    e.preventDefault();

    var firstName = accountSettingsForm.inputFirstName.value;
    var lastName = accountSettingsForm.inputLastName.value;
    var oldPsw = accountSettingsForm.inputOldPassword.value;
    var newPsw = accountSettingsForm.inputNewPassword.value;
    var confirmNewPsw = accountSettingsForm.inputConfirmNewPassword.value;

    $.ajax({
        url:        "/auth/changeAccountSettings",
        type:       "POST",
        dataType:   "json",
        data:       {firstName, lastName, oldPsw, newPsw, confirmNewPsw},
        success: function(data){
            if(data){
                document.getElementById("accountUserName").innerText = data.user;
            }
            accountSettingsErrorMsg.innerText = "Data changed successfully";
            accountSettingsErrorMsg.style.opacity = 1;
        },
        error: function (jqXHR, textStatus, errorThrown ){
                if(jqXHR.status = 400){
                    accountSettingsErrorMsg.innerText = jqXHR.responseText;
                    accountSettingsErrorMsg.style.opacity = 1;
                }
        }
    });
});

// Log out
var logOutBtn = document.getElementById("accountLogOut");
logOutBtn.addEventListener("click", (e) => {
    e.preventDefault();

    $.ajax({
        url:        "/auth/logOut",
        type:       "GET",
        success: function(data){
            location.reload(true);
        },
        error: function (jqXHR, textStatus, errorThrown ){
                if(jqXHR.status = 400){
                    console.log(jqXHR.responseText);
                }
        }
    });
});

// Check cookies
$.ajax({
    url:        "/auth/checkLogin",
    type:       "GET",
    dataType:   "json",
    success: function(data){
        document.getElementById("navLoggedOut").style.display = 'none';
        var navLoggedIn = document.getElementById("navLoggedIn");
        navLoggedIn.style.display = 'flex';
        document.getElementById("accountUserName").innerText = data.user;
        getName();
        getProjects();
    },
    error: function (jqXHR, textStatus, errorThrown ){
            if(jqXHR.status = 400){
                console.log(jqXHR.responseText);
                var navLoggedIn = document.getElementById("navLoggedOut");
                navLoggedIn.style.display = 'flex';
            }
    }
});