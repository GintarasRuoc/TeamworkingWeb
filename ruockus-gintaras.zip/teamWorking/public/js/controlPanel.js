// Change project name Form
var projectName = document.getElementById("projectName");
const openChangeProjectNameForm = document.getElementById("open-change-project-name-form");
const changeProjectNameForm = document.getElementById("change-project-name-form");
const submitChangeProjectNameForm = document.getElementById("change-project-name-form-submit");
var errorChangeProjectNameForm = document.getElementById("change-project-name-error-msg");
var openChangeProjectNameFormValue = false;

openChangeProjectNameForm.addEventListener("click", (e) => {
    if(openChangeProjectNameFormValue == false){
        changeProjectNameForm.style.display = "flex";
        openChangeProjectNameFormValue = true;
    }
    else{
        changeProjectNameForm.style.display = "none";
        openChangeProjectNameFormValue = false;
    }
});

submitChangeProjectNameForm.addEventListener("click", (e) => {
    e.preventDefault();
    var name = changeProjectNameForm.inputProjectName.value;
    $.ajax({
        url:        "/project/changeProjectName",
        type:       "POST",
        data:       {projectName: name},
        dataType:   "json",
        success: function(data){
            projectName.innerText = name;
            errorChangeProjectNameForm.innerText = "Project name changed succefully";
        },
        error: function(jqXHR, textStatus, errorThrown){
            if(jqXHR.status == 400)
                errorChangeProjectNameForm.innerText = jqXHR.responseText;
            else {
                location.replace('/');
            }
        }
    });
    
});

// Delete project
const deleteProjectConfirm = document.getElementById("deleteProjectConfirm");
deleteProjectConfirm.addEventListener("click", (e) => {
    e.stopPropagation();
    $.ajax({
        url:        "/project/deleteProject",
        type:       "GET",
        success: function(data){
            location.replace('/');
        },
        error: function(jqXHR, textStatus, errorThrown){
            location.replace('/');
        }
    });
});

// Add member Form
const openAddMemberForm = document.getElementById("open-add-member-form");
const addMemberForm = document.getElementById("add-member-form");
const submitAddMemberForm = document.getElementById("add-member-form-submit");
var errorAddMemberForm = document.getElementById("add-member-error-msg");
var openAddMemberFormValue = false;

openAddMemberForm.addEventListener("click", (e) => {
    if(openAddMemberFormValue == false){
        addMemberForm.style.display = "flex";
        openAddMemberFormValue = true;
    }
    else{
        addMemberForm.style.display = "none";
        openAddMemberFormValue = false;
    }
});

submitAddMemberForm.addEventListener("click", (e) => {
    e.preventDefault();
    var memberEmail = addMemberForm.inputMemberEmail.value;
    if(memberEmail){
        errorAddMemberForm.innerText = '';
        $.ajax({
            url:        "/project/addMember",
            type:       "POST",
            data:       {email: memberEmail},
            dataType:   "json",
            success: function(data){
                location.reload();
            },
            error: function(jqXHR, textStatus, errorThrown){
                console.log(jqXHR);
                if(jqXHR.status == 403)
                    location.replace('/');
                else if(jqXHR.status == 404)
                    errorAddMemberForm.innerText = jqXHR.responseText;
            }
        });
    }
    else errorAddMemberForm.innerText = 'Please insert member email';
});

// Change member role Form
const openChangeMemberRoleForm = document.getElementById("open-change-member-role-form");
const changeMemberRoleForm = document.getElementById("change-member-role-form");
const submitChangeMemberRoleForm = document.getElementById("change-member-role-form-submit");
var errorChangeMemberRoleForm = document.getElementById("change-member-role-error-msg");
var openChangeMemberRoleFormValue = false;

var memberDropdownChange = document.getElementById("change-member-role-members");

openChangeMemberRoleForm.addEventListener("click", (e) => {
    if(openChangeMemberRoleFormValue == false){
        changeMemberRoleForm.style.display = "flex";
        openChangeMemberRoleFormValue = true;
    }
    else{
        changeMemberRoleForm.style.display = "none";
        openChangeMemberRoleFormValue = false;
    }
});

submitChangeMemberRoleForm.addEventListener("click", (e) => {
    e.preventDefault();
    var id = changeMemberRoleForm.members.value;
    var role = changeMemberRoleForm.roles.value;
    $.ajax({
        url:        "/project/changeMemberRole",
        type:       "POST",
        data:       {id: id, role: role},
        dataType:   "json",
        success: function(data){
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown){
            location.replace("/");
        }
    }) 
});

// Kick member Form
const openKickMemberForm = document.getElementById("open-kick-member-form");
const kickMemberForm = document.getElementById("kick-member-form");
const submitKickMemberForm = document.getElementById("kick-member-form-submit");
var errorKickMemberForm = document.getElementById("kick-member-error-msg");
var openKickMemberFormValue = false;

var memberDropdownKick = document.getElementById("kick-member-members");
openKickMemberForm.addEventListener("click", (e) => {
    if(openKickMemberFormValue == false){
        kickMemberForm.style.display = "flex";
        openKickMemberFormValue = true;
    }
    else{
        kickMemberForm.style.display = "none";
        openKickMemberFormValue = false;
    }
});

submitKickMemberForm.addEventListener("click", (e) =>{
    e.preventDefault();
    $.ajax({
        url:        "/project/kickMember",
        type:       "POST",
        data:       {},
        dataType:   "json",
        success: function(data){
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown){
            location.replace("/");
        }
    })
})

// Check access
$.ajax({
    url:        "/project/check",
    type:       "GET",
    success: function(data){
        if(data.level == 0){
                openChangeProjectNameForm.style.display = "block"
                document.getElementById('delete-project').style.display = "block";
                openAddMemberForm.style.display = "block";
                openChangeMemberRoleForm.style.display = "block";
                openKickMemberForm.style.display = "block";
        }

        projectName.innerText = data.projectName;

        membersTable(data.level, data.members);

        document.getElementById("controlPanel").style.display = "block";
    },
    error: function(jqXHR, textStatus, errorThrown){
        location.location("/");
    }
});

// Members
function membersTable(level, members){
    var select = document.createElement("select");
    var memberTableBody = document.getElementById("memberTableBody");
    members.forEach(element => {
        var user = element.FirstName + " " + element.LastName;
        // Table
        const tr = document.createElement('tr');
        tr.classList.add('my-1');

        const tdName = document.createElement('td');
        tdName.classList.add('col-9');
        tdName.innerText = user;

        const tdRole = document.createElement('td');
        switch(element.Level){
            case 0:
                tdRole.innerText = 'Owner';
                break;
            case 1:
                tdRole.innerText = 'Manager';
                break;
            case 2:
                tdRole.innerText = 'User';
                break;
        }

        tr.appendChild(tdName);
        tr.appendChild(tdRole);

        memberTableBody.appendChild(tr);

        if(level <= 1){
            if(level == 0 && element.Level > 0){
                // Role dropdown
                const optionRole = document.createElement('option');
                optionRole.value = element.Id;
                optionRole.innerText = user;
                memberDropdownChange.appendChild(optionRole);

                // Kick dropdown
                const optionKick = document.createElement('option');
                optionKick.value = element.Id;
                optionKick.innerText = user;
                memberDropdownKick.appendChild(optionKick);
            }
        }
    });
}