export function indicatorActive(){
{/* <li name="indicator" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active indicators" ></li> */}
    const indicator = document.createElement('li');
    indicator.setAttribute('data-bs-target', '#carouselExampleIndicators');
    indicator.setAttribute('data-bs-slide-to', '0');
    indicator.classList.add('active', 'indicators');
    return indicator;
}

export function indicator(){
    const indicator = document.createElement('li');
    indicator.setAttribute('data-bs-target', '#carouselExampleIndicators');
    indicator.setAttribute('data-bs-slide-to', '1');
    indicator.classList.add('indicators');
    return indicator;
}

export function carouselActiveItem(members){
    const carousel = document.createElement('div');
    carousel.classList.add('carousel-item', 'active');

    const form = document.createElement('form');
    form.classList.add('row', 'g-3');
    form.name = 'form';

    // Title
    const titleDiv = title();

    // Description
    const descriptionDiv = description();

    //Worker
    const workerDiv = worker(members);  

    //Progress
    const progressDiv = progress();

    //Color
    const colorDiv = color();

    //Par
    const parDiv = document.createElement('div');
    parDiv.classList.add('col-md-12', 'ms-2');
    const par = document.createElement('p');
    parDiv.appendChild(par);

    //errMsgHolder
    const errMsgDiv = document.createElement('div');
    errMsgDiv.classList.add('col-md-12');
    const errMsgP = document.createElement('input');
    errMsgP.style.border = 'none'
    errMsgP.style.width = '100%';
    errMsgP.classList.add('errorMsg');
    errMsgP.name = 'taskErrorMsg';
    errMsgP.id = 'taskErrorMsg';
    errMsgDiv.appendChild(errMsgP);

    form.appendChild(titleDiv);
    form.appendChild(descriptionDiv);
    form.appendChild(workerDiv);
    form.appendChild(progressDiv);
    form.appendChild(colorDiv);
    form.appendChild(errMsgDiv);
    form.appendChild(parDiv);
    
    carousel.appendChild(form);

    return carousel;
}

export function carouselItem(members){
    const carousel = document.createElement('div');
    carousel.classList.add('carousel-item');

    const form = document.createElement('form');
    form.classList.add('row', 'g-3');
    form.name = 'form';

    // Title
    const titleDiv = title();

    // Description
    const descriptionDiv = description();

    //Worker
    const workerDiv = worker(members);

    //Progress
    const progressDiv = progress();

    //Par
    const parDiv = document.createElement('div');
    parDiv.classList.add('col-md-12', 'ms-2');
    const par = document.createElement('p');
    parDiv.appendChild(par);

    //errMsgHolder
    const errMsgDiv = document.createElement('div');
    errMsgDiv.classList.add('col-md-12');
    const errMsgP = document.createElement('input');
    errMsgP.style.border = 'none'
    errMsgP.style.width = '100%';
    errMsgP.classList.add('errorMsg');
    errMsgP.name = 'taskErrorMsg';
    errMsgP.id = 'taskErrorMsg';
    errMsgDiv.appendChild(errMsgP);

    form.appendChild(titleDiv);
    form.appendChild(descriptionDiv);
    form.appendChild(workerDiv);
    form.appendChild(progressDiv);
    form.appendChild(errMsgDiv);
    form.appendChild(parDiv);
    
    carousel.appendChild(form);

    return carousel;
}

function title(){
    const titleDiv = document.createElement('div');
    titleDiv.classList.add('col-md-12');
    const titleLabel = document.createElement('label');
    titleLabel.classList.add('form-label');
    titleLabel.innerText = 'Task title';
    const titleInput = document.createElement('input');
    titleInput.classList.add('form-control');
    titleInput.name = 'taskTitle';
    titleDiv.appendChild(titleLabel);
    titleDiv.appendChild(titleInput);

    return titleDiv;
}

function description(){
    const descriptionDiv = document.createElement('div');
    descriptionDiv.classList.add('col-md-12');
    const descriptionLabel = document.createElement('label');
    descriptionLabel.classList.add('form-label');
    descriptionLabel.innerText = 'Task description';
    const descriptionTextArea = document.createElement('textarea');
    descriptionTextArea.classList.add('form-control');
    descriptionTextArea.name = 'taskDescription';
    descriptionTextArea.placeholder='Task description...';
    descriptionDiv.appendChild(descriptionLabel);
    descriptionDiv.appendChild(descriptionTextArea);

    return descriptionDiv;
}

function worker(members){
    const workerDiv = document.createElement('div');
    workerDiv.classList.add('col-md-4');
    const workerLabel = document.createElement('label');
    workerLabel.classList.add('form-label');
    workerLabel.innerText = 'Assigned worker: ';
    const workerSelect = document.createElement('select');
    workerSelect.classList.add('form-control');
    workerSelect.name = 'taskWorker';
    const option = document.createElement('option');
    option.value = 0;
    option.innerText = 'Choose person...';
    workerSelect.appendChild(option);
    members.forEach(element => {
        const opt = document.createElement('option');
        opt.value = element.Id;
        opt.innerText = element.FirstName + " " + element.LastName;
        workerSelect.appendChild(opt);
    });
    workerSelect.value = 0;
    workerDiv.appendChild(workerLabel);
    workerDiv.appendChild(workerSelect);    

    return workerDiv;
}

function progress(){
    const progressDiv = document.createElement('div');
    progressDiv.classList.add('col-md-3', 'ms-2');
    const progressLabel = document.createElement('label');
    progressLabel.classList.add('form-label');
    progressLabel.innerText = 'Progress: ';
    const progressSelect = document.createElement('select');
    progressSelect.classList.add('form-control');
    progressSelect.name = 'taskProgress';
    const option0 = document.createElement('option');
    option0.value = 0;
    option0.innerText = 'Not started';
    const option1 = document.createElement('option');
    option1.value = 1;
    option1.innerText = 'In progress';
    const option2 = document.createElement('option');
    option2.value = 2;
    option2.innerText = 'Done';
    progressSelect.appendChild(option0);
    progressSelect.appendChild(option1);
    progressSelect.appendChild(option2);
    progressSelect.value = 0;
    progressDiv.appendChild(progressLabel);
    progressDiv.appendChild(progressSelect);

    return progressDiv;
}

function color(){
    const colorDiv = document.createElement('div');
    colorDiv.classList.add('col-md-4');
    const colorLabel = document.createElement('label');
    colorLabel.classList.add('form-label');
    colorLabel.innerText = 'Select task color: ';
    const colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.classList.add('form-control');
    colorInput.style.height = '38px';
    colorInput.name = 'taskColor';
    colorInput.value = '#ffffff';
    colorDiv.appendChild(colorLabel);
    colorDiv.appendChild(colorInput);

    return colorDiv;
}