import { indicatorActive, indicator, carouselActiveItem, carouselItem } from "./carouselItems.js";
// Carousel items
var indActive, ind, carouselActive, carousel;
const carouselIndicators = document.getElementById('carouselIndicators');
const carouselInner = document.getElementById('carouselInner');; 

var projectBoardsNav = document.getElementById("projectBoardsNav");

var boards = [];
var currentBoard = 0;

const cogImg = document.createElement("img");
cogImg.src = 'img/gear.png';
cogImg.classList.add('gearImg');

// Add board
function addBoard(boardName, boardId){
    const li = document.createElement('li');
    li.classList.add('nav-item');
    var btn = document.createElement('button');
    btn.classList.add('nav-link');
    btn.innerText = boardName;  
    btn.value = boardId;
    li.appendChild(btn);
    projectBoardsNav.appendChild(li);
    boards[boards.length] = btn;
    boards[boards.length - 1] = boardButtonListener(boards[boards.length - 1]);
}

// Board active set up 
function boardButtonListener(btn){
    btn.addEventListener("click", (e) => {
        if(!btn.classList.contains('active')){
            boards[currentBoard] = deactivateButton(boards[currentBoard]);

            currentBoard = boards.indexOf(btn);
            var boardId = boards[currentBoard].value;
            $.ajax({
                url:        "/project/openBoard",
                type:       "POST",
                data:       {boardId: boardId},
                dataType:   "json",
                success: function(data){
                    projectBoardDisplay.innerHTML = '';
                    if(data.tasks){
                        data.tasks.forEach(element => {
                            addTask(element.Id, element.Title, element.Color);
                        });
                    }
                    addTaskCreate();
                }
            })
            
            btn = activateButton(btn);
        }
    });
    return btn;
}

// Activate tab button

function activateButton(btn){
    btn.classList.add('active');
    btn.setAttribute("data-bs-toggle", "modal");
    btn.setAttribute("data-bs-target", "#editBoardModal");
    btn.setAttribute("aria-expanded", "false");
    editBoardForm.inputBoardName.value = btn.innerText;
    btn.appendChild(cogImg);
    editBoardErrorMsg.innerText = "";
    return btn;
}

// Deactivate tab button

function deactivateButton(btn){
    btn.classList.remove('active');
    btn.removeAttribute("data-bs-toggle", "modal");
    btn.removeAttribute("data-bs-target", "#editBoardModal");
    btn.removeAttribute("aria-expanded", "false");

    return btn;
}

// Add create tab 
function addCreateTab(){
    const li = document.createElement('li');
    li.classList.add('nav-item');
    var btn = document.createElement('button');
    btn.classList.add('nav-link');
    btn.innerText = '+';
    btn.setAttribute("data-bs-toggle", "modal");
    btn.setAttribute("data-bs-target", "#createBoardModal");
    btn.setAttribute("aria-expanded", "false");

    li.appendChild(btn);
    boards[boards.length] = li;
    projectBoardsNav.appendChild(li);
}

// Create board 
const createBoardForm = document.getElementById("create-board-form");
const submitCreateBoardForm = document.getElementById("create-board-form-submit");
var createBoardErrorMsg = document.getElementById("create-board-error-msg");

submitCreateBoardForm.addEventListener("click", (e) =>{
    e.stopPropagation();
    var boardName = createBoardForm.inputBoardName.value;
    console.log(boardName);
    $.ajax({
        url:        "/project/addBoard",
        type:       "POST",
        data:       {boardName: boardName},
        dataType:   "json",
        success: function(data){
            projectBoardsNav.removeChild(boards[boards.length - 1]);
            boards = removeItemOnce(boards, boards[boards.length - 1]);
            
            addBoard(createBoardForm.inputBoardName.value);
            addCreateTab();
        },
        error: function(jqXHR, textStatus, errorThrown){
            console.log(jqXHR);
            if(jqXHR.status == 401)
                location.replace('/');
            else createBoardErrorMsg.innerText = jqXHR.responseText;
        }
    });
});

// Edit board name

const editBoardForm = document.getElementById("edit-board-form");
const submitEditBoardForm = document.getElementById("edit-board-form-submit");
var editBoardErrorMsg = document.getElementById("edit-board-error-msg");
const deleteBoard = document.getElementById("edit-board-form-delete");

submitEditBoardForm.addEventListener("click", (e) =>{
    e.stopPropagation();
    var newName = editBoardForm.inputBoardName.value;

    $.ajax({
        url:        "/project/editBoard",
        type:       "POST",
        data:       {newName: newName},
        dataType:   "json",
        success: function(data){
            boards[currentBoard].innerText = editBoardForm.inputBoardName.value;
            editBoardErrorMsg.innerText = "Board name changed successfully";
        },
        error: function(jqXHR, textStatus, errorThrown){
            if(jqXHR.status == 401)
                location.reload();
            else editBoardErrorMsg.innerText = jqXHR.responseText;
        }
    })
})

// Delete board
deleteBoard.addEventListener("click", (e) => {
    $.ajax({
        url:        "/project/deleteBoard",
        type:       "GET",
        success: function(data){
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown){
            location.replace('/');
        }
    });
});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                
//                                                                      TASKs
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var taskCreate;
var projectBoardDisplay = document.getElementById('projectBoardDisplay');

// Add task to board
function addTask( id, title, color){
    const div = document.createElement('div');
    div.classList.add('col-6');
    
    const div1 = document.createElement('div');
    div1.setAttribute('type', 'button');
    div1.classList.add('p-3', 'border');
    div1.innerText = title;
    div1.value = id;
    div1.style.backgroundColor = color;
    div1.setAttribute('data-bs-toggle', 'modal');
    div1.setAttribute('data-bs-target', '#displayTaskModal');

    // Get task info when clicked
    div1.addEventListener("click", (e) =>{
        carouselIndicators.innerHTML = '';
        carouselInner.innerHTML = '';
        $.ajax({
            url:        "/project/getTasksInfo",
            type:       "POST",
            data:       {taskId: id},
            dataType:   "json",
            success: function(data){
                var results = data.results;
                addTaskDisplay(0, results[0], true);
                
                if(results.length > 1);
                    for(var i = 1; i < results.length; i++)
                        addTaskDisplay(i, results[i]);

                if(results.length < 5)
                    addTaskDisplay(results.length);
            },
            error: function(jqXHR, textStatus, errorThrown){

            }
        })
    })

    div.appendChild(div1);
    taskCreate = div;
    projectBoardDisplay.appendChild(taskCreate);

}

// Add task create to board
function addTaskCreate(){
    const div = document.createElement('div');
    div.classList.add('col-6');
    
    const div1 = document.createElement('div');
    div1.setAttribute('type', 'button');
    div1.classList.add('p-3', 'border');
    div1.innerText = 'Create task';
    div1.setAttribute('data-bs-toggle', 'modal');
    div1.setAttribute('data-bs-target', '#createTaskModal');

    div.appendChild(div1);
    projectBoardDisplay.appendChild(div);
}


// Create task
const createTaskForm = document.getElementById("create-task-form");
const submitCreateTaskForm = document.getElementById("create-task-form-submit");
var createTaskErrorMsg = document.getElementById("create-task-error-msg");

submitCreateTaskForm.addEventListener("click", (e) => {
    const taskTitle = createTaskForm.taskTitle.value;
    const taskDescription = createTaskForm.taskDescription.value;
    const taskWorker = createTaskForm.taskWorker.value;
    const taskProgress = createTaskForm.taskProgress.value;
    const taskColor = createTaskForm.taskColor.value;
    $.ajax({
        url:        "/project/addTask",
        type:       "POST",
        data:       {taskTitle: taskTitle, taskDescription: taskDescription,
                taskWorker: taskWorker, taskProgress: taskProgress, taskColor: taskColor},
        dataType:   "json",
        success: function(data){
            projectBoardDisplay.removeChild(projectBoardDisplay.lastChild);
            addTask(data.id, taskTitle, taskColor);
            addTaskCreate();
        },
        error: function(jqXHR, textStatus, errorThrown){
            if(jqXHR.status == 401)
                location.replace('/');
            else createTaskErrorMsg.innerText = jqXHR.responseText;
        }
    });
});

// Add task to display
function addTaskDisplay(index, data, active){
    var tempIndicator, tempCarousel;

    if(active){
        tempIndicator = indActive.cloneNode(true);
        tempCarousel = carouselActive.cloneNode(true);
    }
    else {
        tempIndicator = ind.cloneNode(true);
        tempCarousel = carousel.cloneNode(true);
    }

    tempIndicator.setAttribute('data-bs-slide-to', index);
    carouselIndicators.appendChild(tempIndicator);

    if(data){
        tempCarousel.lastChild.taskTitle.Id = data.Id;
        tempCarousel.lastChild.taskTitle.value = data.Title;
        tempCarousel.lastChild.taskDescription.innerText = data.TaskText;
        tempCarousel.lastChild.taskProgress.value = data.Progress;
        if(active)
            tempCarousel.lastChild.taskColor.value = data.Color;
        if(data.fk_AccountId){
            tempCarousel.lastChild.taskWorker.value = data.fk_AccountId;
        }
    }
    
    carouselInner.appendChild(tempCarousel);
}

// Save task changes
const saveTaskChangesForm = document.getElementById("save-task-changes");

saveTaskChangesForm.addEventListener("click", (e) => {
    e.preventDefault();
    const taskForm = document.getElementsByClassName('carousel-item active')[0].lastChild;
    
    const taskId = taskForm.taskTitle.Id;
    const taskTitle = taskForm.taskTitle.value;
    const taskDescription = taskForm.taskDescription.value;
    const taskWorker = taskForm.taskWorker.value;
    const taskProgress = taskForm.taskProgress.value;
    var taskColor;
    if(taskForm.taskColor)
        taskColor = taskForm.taskColor.value;
    if(taskId)
        $.ajax({
            url:        "/project/editTask",
            type:       "POST",
            data:       {taskId: taskId, taskTitle: taskTitle, taskDescription: taskDescription,
                 taskWorker: taskWorker, taskProgress: taskProgress, taskColor: taskColor},
            dataType:   "json",
            success: function(data){
                console.log(taskForm);
                taskForm.taskErrorMsg.value = "This task was changed successfully";
            },
            error: function(jqXHR, textStatus, errorThrown){
                if(jqXHR.status = 401)
                    location.replace('/');
                else taskForm.taskErrorMsg.value = jqXHR.responseText;
            }
        });
    else
        $.ajax({
            url:        "/project/addTask",
            type:       "POST",
            data:       {taskTitle: taskTitle, taskDescription: taskDescription,
                    taskWorker: taskWorker, taskProgress: taskProgress, taskColor: taskColor},
            dataType:   "json",
            success: function(data){
                taskForm.taskTitle.Id = data.id;
                taskForm.taskErrorMsg.value = "This task was added successfully";
                if(carouselIndicators.childElementCount < 5)
                    addTaskDisplay(carouselIndicators.childElementCount);
            },
            error: function(jqXHR, textStatus, errorThrown){
                if(jqXHR.status == 401)
                    location.replace('/');
                else taskForm.taskErrorMsg.value = jqXHR.responseText;
            }
        });
});

// Delete tasks
const deleteTasksForm = document.getElementById("delete-tasks");

deleteTasksForm.addEventListener("click", (e) => {
    $.ajax({
        url:        "/project/deleteTasks",
        type:       "GET",
        success: function(data){
            location.reload();
        },
        error: function(jqXHR, textStatus, errorThrown){
            location.replace('/');
        }
    })
});

// Remove item from list

function removeItemOnce(arr, value) {
    var index = arr.indexOf(value);
    if (index > -1) {
        arr.splice(index, 1);
    }
    return arr;
}

$.ajax({
    url:        "/project/getBoards",
    type:       "GET",
    success: function(data){
        if(data.boards){
            data.boards.forEach(element => {
                addBoard(element.BoardTitle, element.Id);
            });
            if(data.level != 2)
                addCreateTab();

            activateButton(boards[0]);
            if(data.tasks){
                data.tasks.forEach(element => {
                    addTask(element.Id, element.Title, element.Color);
                });
                if(data.level != 2)
                    addTaskCreate();
            }
            else if(data.level != 2) 
                addTaskCreate();
        }
        else if(data.level != 2)
            addCreateTab();

       if(data.level == 2){
           deleteTasksForm.style.display = "none";
           saveTaskChangesForm.style.display = "none";
       }
    },
    error: function(jqXHR, textStatus, errorThrown){
        location.replace('/');
    }
});


// Get members to display
$.ajax({
    url:        "/project/getMembers",
    type:       "GET",
    success: function(data){
        indActive = indicatorActive();
        ind = indicator();
        carouselActive = carouselActiveItem(data.members);
        carousel = carouselItem(data.members);

        const work = document.getElementById('createTaskWorkers');
        data.members.forEach(element => {
            const option = document.createElement('option');
            option.value = element.Id;
            option.innerText = element.FirstName + " " + element.LastName;
            work.appendChild(option);
        });


    },
    error: function(jqXHR, textStatus, errorThrown){
        location.replace('/');
    }
});