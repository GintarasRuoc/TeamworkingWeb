// Project create request
const projectForm = document.getElementById("project-form");
const projectButton = document.getElementById("project-form-submit");
var projectErrorMsg = document.getElementById("project-error-msg");
projectButton.addEventListener("click", (e) => {
    e.preventDefault();
    const projectName = projectForm.inputProjectName.value;
    
    $.ajax({
        url:        "/auth/projectCreate",
        type:       "POST",
        dataType:   "json",
        data:       {projectName: projectName},
        success: function(data){
            createProjectButton(data.projectName);
            projectErrorMsg.innerText = "Project created successfully";
            projectErrorMsg.style.opacity = 1;
        },
        error: function (jqXHR, textStatus, errorThrown ){
                if(jqXHR.status = 400){
                    projectErrorMsg.innerText = jqXHR.responseText;
                    projectErrorMsg.style.opacity = 1;
                }
        }
    });
});

// Display user projects
function getProjects(){
    $.ajax({ 
        url:        "/auth/getProjects",
        type:       "GET",
        success: function(data){
            if(data)
                data.forEach(element => {
                    createProjectButton(element);
                });
        },
        error: function (jqXHR, textStatus, errorThrown ){
                console.log(jqXHR.responseText);
        }
    })
}

// Display project
function createProjectButton(projectName){
    var tableBody = document.getElementById("projects-table").getElementsByTagName('tbody')[0];

            const tr = document.createElement("tr");
            const th = document.createElement("th");
            th.scope = 'row';
            const button = document.createElement("button");
            button.innerText = projectName;
            button.classList.add('btn', 'btn-line', 'projectButton');

            button.addEventListener("click", (e) =>{
                var name;
                var bool;
                if(projectName.match(/[(]/)){
                    const b = projectName.substring(projectName.indexOf('('));
                    name = projectName.split(b).join("").trim();
                    bool = true;
                }
                else {
                    name = projectName;
                    bool = false;
                }
                $.ajax({
                    url:        "/auth/project",
                    type:       "POST",
                    data:       {name: name, bool: bool},
                    dataType:   "json",
                    success: function(data){
                        if(data)
                            location.replace("/project");
                    },
                    error: function (jqXHR, textStatus, erroThrown){
                        projectErrorMsg.innerText = jqXHR.responseText;
                        projectErrorMsg.opacity = 1;
                    }
                })
            });

            tr.appendChild(th);
            th.appendChild(button);
            tableBody.appendChild(tr);
}