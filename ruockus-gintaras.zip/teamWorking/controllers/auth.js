const mysql = require('mysql');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

dotenv.config({path: './.env'});
// Create connection
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Connect
db.connect((err) => {
    if(err){
        throw err;
    }
});

exports.register = (req, res) => {
    const { firstName, lastName, email, psw, confirmPsw, checkBox} = req.body;
    var errMsg = " ";
    if(!firstName)
        errMsg = "Please enter your first name";
    else if(!lastName)
        errMsg = "Please enter your last name";
    else 
        errMsg = emailValidation(email);
    if(errMsg == " ") 
        errMsg = pswValidation(psw, confirmPsw);
    if(errMsg == " " && checkBox == 'false') 
        errMsg = "Accept terms & conditions!!!";

    if(errMsg == " ")
    {
        db.query('SELECT email FROM user WHERE Email = ?', [email], async (error, results) => {
            if(error) throw error;
            if(results.length > 0){
                errMsg = "Email already exists";
                res.status(400).send(errMsg);  
            }
            else{
                var hashedPassword = await bcrypt.hash(psw, 8);

                db.query('INSERT INTO `user` SET ?', { FirstName: firstName, LastName: lastName, Password: hashedPassword, Email: email}, (error, results) => {
                    if(error){
                        throw error;
                    } else {
                        res.send({message: "Account registered succesfully!!!"})
                    }
                });
            }
        });
    }
    else{
        console.log(errMsg + " Paskutinis");
        res.status(400).send(errMsg);  
    }
}

exports.login = (req, res) => {
    try{
        const { email, psw} = req.body;
        
        if( !email || !psw ){
            console.log("please enter your email and password");
            return res.status(401).send('Please enter your email and password');
        }
        db.query('SELECT * FROM user WHERE Email = ?', [email], async (error, results) => {
            if(error){
                console.log(error);
            }
            // !(await bcrypt.compare(psw, results[0].Password) !(psw == results[0].Password)
            else if( results.length <= 0 ||  !(await bcrypt.compare(psw, results[0].Password)) ){
                console.log("email or password incorrect");
                return res.status(401).send('Email or Password is incorrect...');
            }
            else {
                const id = results[0].Id;
                const token = jwt.sign({ id }, process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES_IN
                });
                //console.log('The token is: ' + token);

                const cookieOptions = {
                    expires: new Date(
                        Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
                    ), httpOnly: true
                }
                res.cookie('jwt', token, cookieOptions);
                res.status(200).send({user: results[0].FirstName + " " + results[0].LastName});
            }
        })
    }
    catch(error){
        console.log(error);
    }
}

exports.user = (req, res) =>{
    try{
        const { id} = req.body;
        db.query('SELECT * FROM user WHERE Id = ?', [id], async (error, results) => {
            res.status(200).send({user: results[0].FirstName + " " + results[0].LastName});
        })
    }
    catch(error) {
        console.log(error);
    }
}

exports.projectCreate = (req, res) =>{
    try {
        var errMsg = "";
        const { projectName} = req.body;
        const idToken = req.cookies.jwt;
        var decode = jwt.verify(idToken, process.env.JWT_SECRET);
        db.query('SELECT Id FROM user WHERE Id = ?', [decode.id], (error, results) => {
            if(error) console.log(error);
            else if(results <= 0){
                errMsg = "Something went wrong, try relog into your account!";
            }
            else if(!projectName){
                errMsg = "Please enter your project name";
            }
            else if(projectName.length > 30){
                errMsg = "Project name can't be longer than 40 letters";
            }
            else if(nameValidation(projectName)){
                errMsg = "Project name can only contain letters, numbers and spaces";
            }
            if(errMsg != "")
                res.status(402).send(errMsg);
            else db.query('SELECT `group`.GroupName FROM `group_access` INNER JOIN `group` ON fk_GroupId = `group`.id ' +
                        'WHERE fk_AccountId = ? AND GroupAccessLevel = 0 AND `group`.GroupName = ?', [decode.id, projectName], (error, results) => {
                if(error) console.log(error);
                else if(results.length > 0){
                    res.status(402).send("You already have project with this name");
                }   
                else{
                    db.query('INSERT INTO `group` SET ?', {GroupName: projectName}, (error, results) => {
                        if(error) throw error;
                        else {
                            db.query('INSERT INTO `group_access` SET ?', {GroupAccessLevel: 0, fk_AccountId: decode.id, fk_GroupId: results.insertId}, (error, results) =>{
                                if(error) throw error;
                                else res.status(200).send({projectName: projectName});
                            })
                        }
                    })
                }
            });
        })  
    } catch (error) {
        console.log(error);
    }
}

exports.changeAccountSettings = (req, res) => {
    try {
        var data = [];
        var errMsg = "";
        const { firstName, lastName, oldPsw, newPsw, confirmNewPsw} = req.body;
        const idToken = req.cookies.jwt;
        var decode = jwt.verify(idToken, process.env.JWT_SECRET);

        if(!firstName)
            errMsg = "Please enter your first name";
        else if (!lastName)
            errMsg = "Please enter your last name";
        
        if(errMsg != "")
            res.status(400).send(errMsg);
        else {
            if(oldPsw || newPsw || confirmNewPsw)
            {
                if(!oldPsw || !newPsw || !confirmNewPsw)
                    res.status(400).send("Please make sure you have filled all password inputs");
                else{
                    db.query('SELECT Password FROM `user` WHERE Id = ? ', [decode.id], async (error, results) => {
                        if(error){
                            console.log(error);
                            res.status(400).send("Something went wrong. Try again");
                        }
                        else if( results.length <= 0 ||  !(await bcrypt.compare(oldPsw, results[0].Password)) ){
                            return res.status(400).send('Old password is incorrect...');
                        }
                        else {
                            if(errMsg = pswValidation(newPsw, confirmNewPsw) != " ")
                                res.status(400).send(errMsg);
                            else{
                                var hashedPassword = await bcrypt.hash(newPsw, 8);
                                db.query('UPDATE `user` SET FirstName = ?, LastName = ?, Password = ? WHERE Id = ? ', 
                                    [firstName, lastName, hashedPassword, decode.id], (error, results) => {
                                        if(error) console.log(error);
                                        res.status(200).send({user: firstName + " " + lastName});
                                });
                            }
                        }
                    });
                }
            }
            else{
                db.query("UPDATE `user` SET FirstName = ?, LastName = ? WHERE Id = ? ", [firstName, lastName, decode.id], (error, results) => {
                    if(error) console.log(error);
                    res.status(200).send({user: firstName + " " + lastName});
                });
            }
        }
    } catch (error) {
        console.log(error);
    }
}

exports.getName = (req, res) => {
    try {
        var data = [];
        const idToken = req.cookies.jwt;
        var decode = jwt.verify(idToken, process.env.JWT_SECRET);
        db.query('SELECT Email, FirstName, LastName FROM `user` WHERE Id = ?', [decode.id], (error, results) => {
            if(error) console.log(error);
            if(results){
                data[0] = results[0].Email;
                data[1] = results[0].FirstName;
                data[2] = results[0].LastName;
                res.status(200).send(data);
            }
            else res.status(400).send("Failed to get information");
        });
    } catch (error) {
        console.log(error);
    }
}

exports.getProjects = (req, res) => {
    try {
        var data = [];
        const idToken = req.cookies.jwt;
        var decode = jwt.verify(idToken, process.env.JWT_SECRET);

        db.query('SELECT `group`.GroupName, `user`.Email, `group_access`.fk_AccountId FROM `group_access` INNER JOIN `group` ON fk_GroupId = `group`.Id ' +
         'INNER JOIN `user` ON fk_AccountId = `user`.Id WHERE GroupAccessLevel = 0 AND fk_GroupId IN ' +
         '(SELECT `group`.id FROM `group_access` LEFT JOIN `group` ON fk_GroupId = `group`.Id WHERE fk_AccountId = ? )', [decode.id], (error, results) => {
            if(error) console.log(error);
            if(results <= 0)
                res.status(200).send();
            else{
                for(var i = 0; i < results.length; i++){
                    if(results[i].fk_AccountId == decode.id)
                        data[i] = results[i].GroupName;
                    else data[i] = results[i].GroupName + " ( " + results[i].Email + ")";
                }
                res.status(200).send(data);
            }
        })
    } catch (error) {
        console.log(error);
    }
}

exports.logOut = (req, res) => {
    try {
        if(req.cookies.jwt){
            const token = 1;
            const cookieOptions = {
                expires: new Date(
                    Date.now()
                ), httpOnly: true
            }
            res.cookie('jwt', token, cookieOptions);
            res.status(200).send();
        }
    } catch (error) {
        console.log(error);
    }
}

exports.checkLogin = (req, res) => {
    try {
        if(req.cookies.jwt){
            const idToken = req.cookies.jwt;
            var decode = jwt.verify(idToken, process.env.JWT_SECRET);

            db.query('SELECT FirstName, LastName FROM `user` WHERE Id = ? ', [decode.id], (error, results) =>{
                if(error) console.log(error);
                if(results <= 0)
                    res.status(400).send('Incorrect cookie');
                else res.status(200).send({user: results[0].FirstName + " " + results[0].LastName});
            });
        }
        else res.status(400).send();
    } catch (error) {
        console.log(error);
    }
}

exports.project = (req, res) => {
    try {
        const {name, bool} = req.body;
        const idToken = req.cookies.jwt;
        var decode = jwt.verify(idToken, process.env.JWT_SECRET);
        db.query('SELECT `group`.Id, `group`.GroupName, `group_access`.GroupAccessLevel FROM `group_access` INNER JOIN `group` ON `group_access`.fk_GroupId = `group`.Id ' + 
                    'WHERE `group_access`.fk_AccountId = ?', [decode.id], (error, results) => {
            if(error) console.log(error);
            else(results.length > 0)
                results.forEach(element => { 
                    if(element.GroupName == name && ((bool == 'true' && element.GroupAccessLevel > 0) || (bool == 'false' && element.GroupAccessLevel < 1))){
                        const id = element.Id;
                        const token = jwt.sign({ id }, process.env.JWT_SECRET, {
                            expiresIn: process.env.JWT_EXPIRES_IN
                        });

                        const cookieOptions = {
                            expires: new Date(
                                Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
                            ), httpOnly: true
                        }
                        res.cookie('id', token, cookieOptions);
                        res.status(200).send({message: 'Access granted'});
                    }
                });
        });
    } catch (error) {
        console.log(error);
    }
}

// Password validation
function pswValidation( psw, confirmPsw){
    var msg = " ";

    if(!psw || !confirmPsw)
        msg = "Please enter your password";
    else if(isAllSymbolsAllowed(psw))
        msg = "Password can only contain numbers and latin alphabet letters";
    else if(psw.length < 8)
        msg = "Password must be longer that 8 symbols";
    else if(isContainsUpperLetter(psw) == false)
        msg = "Password must contain at least 1 upper case letter";
    else if(isContainsNumber(psw) == false)
        msg = "Password must contain at least 1 number";
    else if(psw != confirmPsw)
        msg = "Passwords does not match";
    return msg;
}

function isAllSymbolsAllowed(psw){
    psw = psw.replace(/[A-Za-z0-9]/g, '');
    return psw.length > 0;
}

function isContainsUpperLetter(psw){
    return /[A-Z]/.test(psw);
}

function isContainsNumber(psw){
    return /[0-9]/.test(psw);
}

// Email validation
function emailValidation( email){
    var msg = " ";

    if(!email)
        msg = "Please enter your email adress";
    else if(!/[A-Za-z0-9.-]+@+[a-z]+.+[a-z]/.test(email)){
        msg = "Invalid email address. Example: pattern@email.com";
    }

    return msg;
}

// Check if name allowed
function nameValidation(name){
    name = name.replace(/[A-Za-z0-9 ]/g, '');
    return name.length > 0
}