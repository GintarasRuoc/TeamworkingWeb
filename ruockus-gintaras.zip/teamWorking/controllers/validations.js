// Password validation
export function pswValidation( psw, confirmPsw){
    var msg = " ";

    if(!psw || !confirmPsw)
        msg = "Please enter your password";
    else if(isAllSymbolsAllowed(psw))
        msg = "Password can only contain numbers and latin alphabet letters";
    else if(psw.length < 8)
        msg = "Password must be longer that 8 symbols";
    else if(isContainsUpperLetter(psw) == false)
        msg = "Password must contain at least 1 upper case letter";
    else if(isContainsNumber(psw) == false)
        msg = "Password must contain at least 1 number";
    else if(psw != confirmPsw)
        msg = "Passwords does not match";
    return msg;
}

function isAllSymbolsAllowed(psw){
    psw = psw.replace(/[A-Za-z0-9]/g, '');
    console.log("password " + psw);
    return psw.length > 0;
}

function isContainsUpperLetter(psw){
    return /[A-Z]/.test(psw);
}

function isContainsNumber(psw){
    return /[0-9]/.test(psw);
}


// Email validation
export function emailValidation( email){
    var msg = " ";

    if(!email)
        msg = "Please enter your email adress";
    else if(!/[A-Za-z0-9.-]+@+[a-z]+.+[a-z]/.test(email)){
        msg = "Invalid email address. Example: pattern@email.com";
    }

    return msg;
}

// Name validation
export function nameValidation( name){
    var msg = " ";



    return msg;
}