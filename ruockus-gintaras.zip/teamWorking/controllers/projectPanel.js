const mysql = require('mysql');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

var accessLevel;
var projectIdGlobal;

dotenv.config({path: './.env'});
// Create connection
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Connect
db.connect((err) => {
    if(err){
        throw err;
    }
});

exports.check = (req, res) => {
    const projectToken = req.cookies.id;
    const projectId = jwt.verify(projectToken, process.env.JWT_SECRET);
    const userToken = req.cookies.jwt;
    const userId = jwt.verify(userToken, process.env.JWT_SECRET);
    db.query('SELECT `group_access`.GroupAccessLevel, `group`.GroupName FROM `group_access` INNER JOIN `group` ON `group_access`.fk_GroupId = `group`.Id ' +
            'WHERE `group_access`.fk_AccountId = ? AND `group`.Id = ?', [userId.id, projectId.id], (error, results) => {
                if(error) console.log(error);
                else if(results.length == 1){
                    var level = results[0].GroupAccessLevel;
                    accessLevel = level;
                    projectIdGlobal = projectId.id;
                    var projectName = results[0].GroupName;
                    db.query('SELECT `group_access`.fk_AccountId as Id, `user`.FirstName, `user`.LastName, `group_access`.GroupAccessLevel as Level FROM `group_access` ' +
                                'INNER JOIN `user` ON `group_access`.fk_AccountId = `user`.`Id` WHERE `group_access`.fk_GroupId = ? ' +
                                'ORDER BY `group_access`.GroupAccessLevel', [projectId.id], (error, results) =>{
                        if(error) console.log(error)
                        else if(results.length > 0){
                            res.status(200).send({level: level, projectName: projectName, members: results});
                        }  
                        else res.status(403).send();
                    });
                }
                else res.status(403).send();
            });
}

exports.changeProjectName = (req, res) =>{
    var errMsg = "";
    const {projectName} = req.body;
    const userToken = req.cookies.jwt;
    const userId = jwt.verify(userToken, process.env.JWT_SECRET);
    if(accessLevel == 0){
        if(nameValidation(projectName))
            res.status(400).send("Project name can only contain letters, numbers and spaces");
        else {
            db.query('SELECT `group`.GroupName FROM `group_access` INNER JOIN `group` ON `group_access`.fk_GroupId = `group`.id ' +
                        'WHERE fk_AccountId = ? AND GroupAccessLevel = 0 AND `group`.GroupName = ?', [userId.id, projectName], (error, results) => {
                            if(error) console.log(error);
                            else if(results.length > 0)
                                res.status(400).send("You already have project with this name");
                            else db.query('UPDATE `group` SET `group`.GroupName = ? WHERE `group`.Id = ?', [projectName, projectIdGlobal], (error, results) =>{
                                console.log("Pakeite");
                                if(error) console.log(error);
                                else res.status(200).send();
                            });
                        });
        }
    }
    else res.status(403).send();
}

// Check if name allowed
function nameValidation(name){
    name = name.replace(/[A-Za-z0-9 ]/g, '');
    return name.length > 0
}

exports.deleteProject = (req, res) => {
    if(accessLevel == 0){
        db.query('DELETE `group` FROM `group` WHERE `group`.Id = ?', [projectIdGlobal], (error, results) => {
            if(error) console.log(error);
            else res.status(200).send();
        })
    }
    else res.status(401).send();
}

exports.addMember = (req, res) => {
    const {email} = req.body;
    if(accessLevel == 0){
        db.query('SELECT Id FROM `user` WHERE Email = ? ', [email], (error, results) => {
            if(error) console.log(error);
            else if(results.length == 1){
                db.query('INSERT INTO `group_access` SET ?', {GroupAccessLevel: 2, fk_AccountId: results[0].Id, fk_GroupId: projectIdGlobal}, (error, results) => {
                    if(error) console.log(error);
                    else res.status(200).send({message: 'User added'});
                });
            }
            else res.status(404).send("User not found");
        });
    }
    else res.status(403).send();
}

exports.changeMemberRole = (req, res) => {
    const {id, role} = req.body;
    const projectToken = req.cookies.id;
    const projectId = jwt.verify(projectToken, process.env.JWT_SECRET);
    if(accessLevel == 0){
        db.query('UPDATE `group_access` SET `group_access`.GroupAccessLevel = ? WHERE `group_access`.fk_AccountId = ? ' +
                    'AND `group_access`.fk_GroupId = ?', [role, id, projectIdGlobal], (error, results) => {
                        if(error) console.log(error);
                        else res.status(200).send();
                    });
    }
    else res.status(403).send();
}

exports.kickMember = (req, res) => {
    const {id} = req.body;
    const projectToken = req.cookies.id;
    const projectId = jwt.verify(projectToken, process.env.JWT_SECRET);

    if(accessLevel == 0){
        db.query('DELETE FROM `group_access` WHERE `group_access`.fk_AccountId = ?' [id], (error, results) => {
            if(error) console.log(error);
            else res.status(200).send();
        });
    }
    else res.status(403).send();
}

exports.getMembers = (req, res) =>{
    db.query('SELECT `group_access`.fk_AccountId as Id, `user`.FirstName, `user`.LastName FROM `group_access` ' +
                'INNER JOIN `user` ON `group_access`.fk_AccountId = `user`.`Id` WHERE `group_access`.fk_GroupId = ? ' +
                'ORDER BY `group_access`.GroupAccessLevel', [projectIdGlobal], (error, results) =>{
        if(error) console.log(error)
        else if(results.length > 0){
            res.status(200).send({members: results});
        }  
        else res.status(403).send();
    });
}

function unauthorized(){

}