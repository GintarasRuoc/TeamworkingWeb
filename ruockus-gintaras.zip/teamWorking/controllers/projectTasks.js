const mysql = require('mysql');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

var accessLevel;
var projectIdGlobal;
var currentTaskId;
var currentBoardId;

dotenv.config({path: './.env'});
// Create connection
const db = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
});

// Connect
db.connect((err) => {
    if(err){
        throw err;
    }
});

exports.getBoards = (req, res) => {
    const projectToken = req.cookies.id;
    const projectId = jwt.verify(projectToken, process.env.JWT_SECRET);
    const userToken = req.cookies.jwt;
    const userId = jwt.verify(userToken, process.env.JWT_SECRET);
    projectIdGlobal = projectId.id;
    db.query('SELECT `group_access`.GroupAccessLevel FROM `group_access` WHERE `group_access`.fk_AccountId = ? AND `group_access`.fk_GroupId = ? ',
                 [userId.id, projectId.id], (error, results) =>{
        if(error) console.log(error);
        else if(results.length > 0){
            accessLevel = results[0].GroupAccessLevel;
            db.query('SELECT `board`.BoardTitle, `board`.Id FROM `board` WHERE `board`.fk_GroupId = ?', [projectIdGlobal], (error, results) =>{
                if(error) console.log(error);
                else if(results.length > 0){
                    var boards = results;
                    currentBoardId = boards[0].Id;
                    db.query('SELECT `tasks`.Title, `tasks`.Color, `tasks`.Id FROM `tasks` INNER JOIN `board` ON `tasks`.fk_BoardId = `board`.Id ' +
                                'WHERE `board`.BoardTitle = ? AND `tasks`.fk_AttachedTaskId IS NULL', [results[0].BoardTitle], (error, results) =>{
                        if(error) console.log(error);
                        else if(results.length > 0){
                            res.status(200).send({level: accessLevel, message: 'success', boards: boards, tasks: results})
                        }
                        else res.status(200).send({level: accessLevel, message: 'success', boards: boards});
                    })
                }
                else res.status(200).send({level: accessLevel, message: 'success'});
            });
        }
        else res.status(401).send("User not found");
    });
}

exports.addBoard = (req, res) => {
    var errMsg = "";
    const {boardName} = req.body;
    if(accessLevel <= 1){
        if(!boardName)
            errMsg = "Please enter board name";
        else if(boardName.length > 20)
            errMsg = "Board name can't be longer than 20 symbols";
        else if(nameValidation(boardName))
            errMsg = "Board name can only contain letters, numbers and spaces";
        if(errMsg == ""){
            db.query('SELECT `board`.BoardTitle FROM `board` WHERE `board`.BoardTitle = ? AND `board`.fk_GroupId = ?', [boardName, projectIdGlobal], (error, results) => {
                if(error) console.log(error);
                else if(results.length > 0)
                    res.status(400).send("Board with this name already exists");
                else {
                    db.query('INSERT INTO `board` SET ?', {BoardTitle: boardName, fk_GroupId: projectIdGlobal}, (error, results) =>{
                        if(error) console.log(error);
                        else {
                            if(!currentBoardId)
                                currentBoardId = results.insertId;
                            res.status(200).send({boardName: boardName});
                        }
                    });
                }
            });
        }
        else res.status(400).send(errMsg);
    }
    else res.status(401).send();
}

exports.editBoard = (req, res) => {
    var errMsg = "";
    const {newName} = req.body;

    if(accessLevel <= 1){
        if(!newName)
            errMsg = "Please enter board name";
        else if(newName.length > 20)
            errMsg = "Board name can't be longer than 20 symbols";
        else if(nameValidation(newName))
            errMsg = "Board name can only contain letters, numbers and spaces";
        if(errMsg == ""){
            db.query('SELECT `board`.BoardTitle FROM `board` WHERE `board`.BoardTitle = ? AND `board`.fk_GroupId = ?', [newName, projectIdGlobal], (error, results) => {
                if(error) console.log(error);
                else if(results.length > 0)
                    res.status(400).send("Board with this name already exists");
                else {
                    db.query('UPDATE `board` SET `board`.BoardTitle = ? WHERE `board`.Id = ?', [newName, currentBoardId], (error, results) =>{
                        if(error) console.log(error);
                        else res.status(200).send({boardName: newName});
                    });
                }
            });
        }
        else res.status(400).send(errMsg);
    }
    else res.status(401).send();
}

exports.openBoard = (req, res) => {
    const {boardId} = req.body;

    db.query('SELECT `tasks`.Title, `tasks`.Color, `tasks`.Id FROM `tasks` WHERE `tasks`.fk_BoardId = ? AND `tasks`.fk_AttachedTaskId IS NULL', [boardId], (error, results) =>{
        if(error) console.log(error);
        else {
            currentBoardId = boardId;
            if(results.length > 0)
                res.status(200).send({message: 'success', tasks: results});
            else res.status(200).send({message: 'success'});
        }
    });
}

exports.deleteBoard = (req, res) => {
    if(accessLevel <= 1){
        db.query('DELETE `board` FROM `board` WHERE `board`.Id = ?', [currentBoardId], (error, results) => {
            if(error) console.log(error);
            else{
                console.log(results);
                res.status(200).send();
            }
        });
    }
    else res.status(401).send();
}

exports.addTask = (req, res) => {
    var errMsg = "";
    const {taskTitle, taskDescription, taskWorker, taskProgress, taskColor} = req.body;
    if(accessLevel <= 1){
        if(!currentBoardId)
            errMsg = "Something is wrong. Try restarting the page.";
        else if(!taskTitle)
            errMsg = "Please insert task title";
        else if(!taskDescription)
            errMsg = "Please insert task description";
        else if(nameValidation(taskTitle))
            errMsg = "Title and description can only contain letters, numbers and spaces"; 
        if(errMsg == ""){
            if(taskColor)
                db.query('SELECT `tasks`.Title FROM `tasks` WHERE `tasks`.fk_BoardId = ? AND `tasks`.Title = ? AND `tasks`.fk_AttachedTaskId IS NULL',
                            [currentBoardId, taskTitle], (error, results) => {
                    if(error) console.log(error);
                    else {
                        if(results.length > 0)
                            errMsg = "Task with this title already exists";

                        if(errMsg == ""){
                            if(taskWorker == 0)
                                db.query('INSERT INTO `tasks` SET ? ', {Title: taskTitle, TaskText: taskDescription, 
                                    Progress: taskProgress, Color: taskColor, fk_BoardId: currentBoardId}, (error, results) =>{
                                    if(error) console.log(error);
                                    else res.status(200).send({id: results.insertId});
                                });
                            else {
                                db.query('INSERT INTO `tasks` SET ? ', {Title: taskTitle, TaskText: taskDescription, 
                                        Progress: taskProgress, Color: taskColor, fk_BoardId: currentBoardId, fk_AccountId: taskWorker}, (error, results) =>{
                                        if(error) console.log(error);
                                        else res.status(200).send({id: results.insertId});
                                });
                            }
                        }
                        else res.status(400).send(errMsg);
                    }
                });
            else if(taskWorker == 0)
                db.query('INSERT INTO `tasks` SET ? ', {Title: taskTitle, TaskText: taskDescription, 
                    Progress: taskProgress, fk_BoardId: currentBoardId, fk_AttachedTaskid: currentTaskId}, (error, results) => {
                        if(error) console.log(error);
                        else res.status(200).send({id: results.insertId});
                    });
            else 
                db.query('INSERT INTO `tasks` SET ? ', {Title: taskTitle, TaskText: taskDescription, 
                    Progress: taskProgress, fk_BoardId: currentBoardId, fk_AccountId: taskWorker, fk_AttachedTaskid: currentTaskId}, (error, results) => {
                        if(error) console.log(error);
                        else res.status(200).send({id: results.insertId});
                    });
        }
        else res.status(400).send(errMsg);
    }
    else res.status(401).send();
}

exports.getTasksInfo = (req, res) => {
    const {taskId} = req.body;

    db.query('SELECT * FROM `tasks` WHERE `tasks`.Id = ? OR `tasks`.fk_AttachedTaskId = ?', [taskId, taskId], (error, results) => {
        if(error) console.log(error)
        else if(results.length > 0){
            currentTaskId = taskId;
            res.status(200).send({results: results});
        }
        else res.status(404).send();
    });
    
}

exports.editTask = (req, res) => {
    var errMsg ="";
    var {taskId, taskTitle, taskDescription, taskWorker, taskProgress, taskColor} = req.body;
    if(taskWorker == 0)
        taskWorker = 'null';
    if(accessLevel <= 1){
        if(!taskTitle)
            errMsg = "Please insert task title";
        else if(!taskDescription)
            errMsg = "Please insert task description";
        else if(nameValidation(taskTitle))
            errMsg = "Title and description can only contain letters, numbers and spaces"; 
        if(errMsg == ""){
            if(taskColor)
                if(taskWorker == 0)
                    db.query('UPDATE `tasks` SET `tasks`.Title = ?, `tasks`.TaskText = ?, `tasks`.Progress = ?, `tasks`.Color = ?WHERE `tasks`.Id = ?',
                        [taskTitle, taskDescription, taskProgress, taskColor, taskId], (error, result) =>{
                    if(error) console.log(error);
                    else res.status(200).send();
                    });
                
                else 
                    db.query('UPDATE `tasks` SET `tasks`.Title = ?, `tasks`.TaskText = ?, `tasks`.Progress = ?, `tasks`.Color = ?, `tasks`.fk_AccountId = ? WHERE `tasks`.Id = ?',
                        [taskTitle, taskDescription, taskProgress, taskColor, taskWorker, taskId], (error, result) =>{
                    if(error) console.log(error);
                    else res.status(200).send();
                    });
            else 
                if(taskWorker == 0)
                    db.query('UPDATE `tasks` SET `tasks`.Title = ?, `tasks`.TaskText = ?, `tasks`.Progress = ? WHERE `tasks`.Id = ?',
                        [taskTitle, taskDescription, taskProgress, taskId], (error, result) =>{
                            if(error) console.log(error);
                            else res.status(200).send();
                        });
                else
                    db.query('UPDATE `tasks` SET `tasks`.Title = ?, `tasks`.TaskText = ?, `tasks`.Progress = ?, `tasks`.fk_AccountId = ? WHERE `tasks`.Id = ?',
                        [taskTitle, taskDescription, taskProgress, taskWorker, taskId], (error, result) =>{
                            if(error) console.log(error);
                            else res.status(200).send();
                        });
            
        }
        else res.status(400).send(errMsg);
    }
    else res.status(401).send();

}

exports.deleteTasks = (req, res) => {
    console.log(currentTaskId);
    if(accessLevel <= 1)
        db.query('DELETE FROM `tasks` WHERE `tasks`.Id = ?', [currentTaskId, currentTaskId], (error, results) => {
            if(error) console.log(error);
            else res.status(200).send();
        });
    else res.status(401).send();
}

// Check if name allowed
function nameValidation(name){
    name = name.replace(/[A-Za-z0-9 ]/g, '');
    return name.length > 0
}
