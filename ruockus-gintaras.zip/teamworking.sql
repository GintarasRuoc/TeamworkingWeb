-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2021 at 10:55 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teamworking`
--

-- --------------------------------------------------------

--
-- Table structure for table `board`
--

CREATE TABLE `board` (
  `Id` int(11) NOT NULL,
  `BoardTitle` varchar(20) NOT NULL,
  `fk_GroupId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `board`
--

INSERT INTO `board` (`Id`, `BoardTitle`, `fk_GroupId`) VALUES
(5, 'Testas', 21);

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `Id` int(11) NOT NULL,
  `GroupName` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`Id`, `GroupName`) VALUES
(21, 'projektas'),
(22, 'my project');

-- --------------------------------------------------------

--
-- Table structure for table `group_access`
--

CREATE TABLE `group_access` (
  `Id` int(11) NOT NULL,
  `GroupAccessLevel` int(11) NOT NULL,
  `fk_AccountId` int(11) NOT NULL,
  `fk_GroupId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_access`
--

INSERT INTO `group_access` (`Id`, `GroupAccessLevel`, `fk_AccountId`, `fk_GroupId`) VALUES
(20, 0, 22, 21),
(21, 2, 21, 21),
(22, 0, 21, 22);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `Id` int(11) NOT NULL,
  `Title` varchar(20) NOT NULL,
  `TaskText` text NOT NULL,
  `Progress` int(11) NOT NULL,
  `Color` char(7) DEFAULT NULL,
  `fk_BoardId` int(11) NOT NULL,
  `fk_AccountId` int(11) DEFAULT NULL,
  `fk_AttachedTaskId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`Id`, `Title`, `TaskText`, `Progress`, `Color`, `fk_BoardId`, `fk_AccountId`, `fk_AttachedTaskId`) VALUES
(48, 'Testas', 'testas', 1, '#c89393', 5, 21, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(40) NOT NULL,
  `LastName` varchar(40) NOT NULL,
  `Password` varchar(128) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `WebAccessLevel` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `FirstName`, `LastName`, `Password`, `Email`, `WebAccessLevel`) VALUES
(21, 'Vardenis', 'Pavardenis', '$2b$08$lXcQoM5WgNuZlgocVqk5x.Gr.AXpN3Xu9aGh1K9u9WI7x/Xpbg8Oa', 't@t.t', 1),
(22, 'testas', 'testas', '$2b$08$mXNlzqD6Viz9buWmZeK4KuX7nPMejoy1UYK2zv5Av.OX.bfPNWiNG', 'testas@gmail.com', 1),
(23, 'b', 'b', '$2b$08$LeFbW7x/WM4ilRflY4eOlOe5nwr2hAdcuxcdqRfSnBbZGtrDl47ZG', 'b@b.b', 1),
(24, 'l', 'l', '$2b$08$.5yWL8nEtsC7GDRTknZwdOu2aChFJXBpWxTVNv6pmcMpBhW1oJ4Oa', 'l@l.l', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_GroupId` (`fk_GroupId`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `group_access`
--
ALTER TABLE `group_access`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_AccountId` (`fk_AccountId`),
  ADD KEY `fk_GroupId` (`fk_GroupId`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `fk_BoardId` (`fk_BoardId`),
  ADD KEY `fk_AccountId` (`fk_AccountId`),
  ADD KEY `fk_AttachedTaskId` (`fk_AttachedTaskId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `board`
--
ALTER TABLE `board`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `group_access`
--
ALTER TABLE `group_access`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `board`
--
ALTER TABLE `board`
  ADD CONSTRAINT `board_ibfk_1` FOREIGN KEY (`fk_GroupId`) REFERENCES `group` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `group_access`
--
ALTER TABLE `group_access`
  ADD CONSTRAINT `group_access_ibfk_1` FOREIGN KEY (`fk_AccountId`) REFERENCES `user` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `group_access_ibfk_2` FOREIGN KEY (`fk_GroupId`) REFERENCES `group` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_4` FOREIGN KEY (`fk_AttachedTaskId`) REFERENCES `tasks` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tasks_ibfk_5` FOREIGN KEY (`fk_AccountId`) REFERENCES `user` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tasks_ibfk_6` FOREIGN KEY (`fk_BoardId`) REFERENCES `board` (`Id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
